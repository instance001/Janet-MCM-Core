# Contributing to Janet (MCM Core)

Thank you for your interest in improving Janet — the reference implementation of the Modest Cognition Model (MCM).

Janet is deterministic, transparent, and safety‑aligned. Contributions must preserve these guarantees.

## 🧠 Core Principles

All contributions MUST adhere to:

1. **Determinism**
   - No randomness
   - No probabilistic inference
   - No hidden state

2. **Modesty**
   - No attempts to make Janet conversational, emotional, or persona‑based.
   - No simulation of human traits.

3. **Explicitness**
   - All logic must be fully inspectable.
   - No “magic,” no implicit state, no uncontrolled complexity.

4. **Human‑Governed Growth**
   - Skills must not self‑modify.
   - Memory must not be written automatically.
   - Promotion to stable memory requires explicit human approval.

5. **Bounded Cognition**
   - Skill depth must not exceed configured maximums.
   - Skill composition must remain shallow and explicit.

## 📁 Repository Structure Expectations

When adding files:

```
janet/
  skills/
    domain/
      your_skill.py
  test_lab/
  workshop/
  examples/
  docs/
```

Follow the existing patterns for clarity and auditability.

## 🛠 Adding a Skill

Each skill must contain:

```
def metadata():
    return {
        "skill_name": "...",
        "input_schema": {...},
        "output_schema": {...},
        "tags": [...],
        "prereqs": [...]
    }

def execute(**kwargs):
    ...
```

### Requirements:

- Use **typed inputs** only.
- Validate all fields.
- No I/O inside skills.
- Execution must be **pure** (no side effects).
- Keep skills extremely small (5–30 lines recommended).

## 🧪 Tests

All new skills must include:

- A sandbox test (`test_lab/sandbox.py` compatible)
- A stress‑case entry if applicable
- At least one JSON example

## 🔐 Safety Review Checklist

Before submitting a PR:

- [ ] No global state introduced
- [ ] No nondeterminism
- [ ] No recursion beyond allowed depth
- [ ] No complex control flow that hides behavior
- [ ] Skill clearly names its domain
- [ ] Execution predictable across runs

## 📝 Pull Requests

PRs must include:

1. A description of the purpose
2. A diff that is easy to audit
3. Notes on safety considerations
4. Tests and examples

Thanks for helping build the first open-source Modest Cognition Model.
