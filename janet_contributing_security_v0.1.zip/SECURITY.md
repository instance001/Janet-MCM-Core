# Security Policy for Janet (MCM Core)

Janet is designed around **safety by architecture**, not by filters or guardrails.  
This policy ensures contributions do not compromise deterministic behavior, explicit memory, or bounded cognition.

## 🧱 1. Supported Versions
Only the latest minor version (v0.x) receives security updates.

## 🛡 2. Principles of Secure MCM Design

### Determinism
Janet must never rely on:
- randomness
- probability
- external hidden state
- uncontrolled third-party libraries

### Memory Integrity
- Runtime is not allowed to write Stable Memory.
- Candidate Memory is permitted only through the controlled logging interface.
- Promotion to Stable Memory requires human action.

### No Self‑Modification
Janet must not:
- load code at runtime,
- modify skills,
- modify selectors,
- bypass the curriculum gates.

### Bounded Cognition
- Maximum selector depth is enforced.
- Maximum skill composition depth is enforced.
- Skill count must remain small and modular.

## 🐛 3. Reporting a Vulnerability

If you discover an issue that may:
- introduce nondeterminism,
- allow unreviewed memory writes,
- enable emergent behavior,
- or create uncontrolled skill chaining,

please open a **Private Security Issue** via GitHub or contact the repo maintainers directly.

## ✔ 4. Allowed Experiments

You may safely experiment with:
- new deterministic skills
- new curriculum tests
- new selector heuristics (deterministic only)
- new sandbox/stress harness mechanisms

## ❌ 5. Prohibited Modifications

Do NOT submit changes that:
- introduce randomness
- integrate LLMs directly into runtime
- allow self‑training or self‑growth
- bypass human approval in memory promotion
- expand Janet into a conversational agent

## 🔍 6. Audits

Janet’s architecture is meant to be auditable.  
Periodic full-text diffs of:
- skills/
- selectors/
- memory/

are strongly encouraged to maintain safety.

Thank you for helping keep Janet deterministic, transparent, and modest.
