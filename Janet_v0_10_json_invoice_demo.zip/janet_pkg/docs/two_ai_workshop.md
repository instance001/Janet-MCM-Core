# Two-AI Workshop – Janet + LLM Composite Pattern

The **Two-AI Workshop** shows how an LLM and Janet can cooperate.

## Roles

- **LLM**
  - Interprets messy natural language
  - Resolves ambiguity where possible
  - Translates user requests into **strict Janet input strings**
  - Explains Janet's results to humans

- **Janet**
  - Accepts only tightly scoped command strings
  - Executes deterministic skills based on explicit schemas
  - Refuses ambiguous or malformed inputs via `AmbiguousTaskError`
  - Logs all runs to the memory spine

## Example Flow

1. User: "Can you check if this invoice adds up correctly?"
2. LLM: converts to  
   `verify invoice total 120 equals items 50, 70`
3. Janet:
   - Normalizes and parses the string
   - Routes to `invoice` mode and `invoice_verify_total` skill
   - Computes the sum and compares against total
4. LLM:
   - Reads Janet's output: `{"ok": true, "sum": 120, "total": 120}`
   - Explains: "The line items add to 120, which matches the invoice total."

## Why This Matters

- The **LLM** remains flexible but can be wrong or fuzzy.
- **Janet** is constrained but reliable and auditable.
- Together they form a **composite cognition system** that is both:
  - user-friendly and expressive (LLM side)
  - structurally safe and inspectable (Janet side).

The included `two_ai_workshop/two_ai_demo.py` script gives a stubbed version
of this loop without calling a real LLM, to make the pattern concrete.
