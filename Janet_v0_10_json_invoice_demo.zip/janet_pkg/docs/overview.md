# Janet – Modest Cognition Model (MCM) Overview

Janet is a **Modest Cognition Model (MCM)** core:
a deterministic, non-neural, non-stochastic cognition engine designed
for **inspectable, auditable reasoning**.

It is not a Large Language Model (LLM). It does not:
- predict next tokens
- use weights or embeddings at runtime
- maintain hidden conversational state
- simulate persona or emotions

Instead, Janet is built from:
- **skills** – small, pure functions with explicit schemas
- **selectors** – deterministic routers that pick skills and modes
- **memory spine** – explicit, file-based logs and (future) promoted memories
- **curriculum & tests** – lesson-like flows used to add new skills safely

This repository contains a minimal prototype that can:
- add and multiply two integers
- verify a simple invoice total against line items
- log all runs to a memory folder
- surface ambiguity via a dedicated error type
- run a small smoke test suite and a Two-AI composite demo
