# MCM vs LLM – What Janet Is and Is Not

## Large Language Models (LLMs)

LLMs (like GPT-style systems) are:
- neural
- stochastic
- trained with gradient descent on large text corpora
- optimized to predict the next token
- capable of rich language understanding and generation
- opaque at the internal reasoning level

They are powerful but:
- can hallucinate
- can drift in persona
- do not give step-by-step program traces by default
- are hard to audit in high-stakes environments

## Modest Cognition Models (MCMs)

An MCM like Janet is:
- **non-neural** at runtime
- **deterministic** – same input → same output, always
- composed of **small skills** (functions) and **selectors**
- wired to use **explicit schemas** and **file-based memory**

Key properties:
- No probabilistic inference in the core loop
- No hidden internal state
- No persona simulation
- Growth via **adding skills and selectors**, not parameters

MCMs trade broad generality for:
- predictability
- inspectability
- safety in critical workflows
- ease of reasoning about what the system can and cannot do

## How Janet and an LLM Can Work Together

In the Two-AI Workshop pattern:
- The LLM handles: open-ended language, ambiguity, user interaction
- Janet handles: deterministic checks, verification, constrained logic

This forms a **composite cognition loop** where:
- The LLM proposes or translates a task into a strict Janet input string
- Janet executes deterministically and logs the result
- The LLM explains or contextualizes the result back to the user

Janet is the "grounding rail"; the LLM is the "language front-end".
