"""Janet v0.3 – Minimal smoke test harness.

Run with:
    python -m test_lab.run_smoke_tests
or from root:
    python test_lab/run_smoke_tests.py
"""

from janet import run_janet
from janet_errors import AmbiguousTaskError

TESTS = [
    {
        "name": "add basic",
        "input": "add 5 and 7",
        "expect_error": False,
        "expected_output": {"result": 12},
    },
    {
        "name": "multiply basic",
        "input": "multiply 3 and 4",
        "expect_error": False,
        "expected_output": {"result": 12},
    },
    {
        "name": "invoice total ok",
        "input": "verify invoice total 120 equals items 50, 70",
        "expect_error": False,
        "expected_output": {"ok": True, "sum": 120, "total": 120},
    },
    {
        "name": "ambiguous add (words instead of numbers)",
        "input": "add five and seven",
        "expect_error": True,
        "expected_output": None,
    },
    {
        "name": "ambiguous invoice (bad total)",
        "input": "verify invoice total apples equals items 1, 2",
        "expect_error": True,
        "expected_output": None,
    },
]


def run_all_tests():
    passed = 0
    failed = 0
    for t in TESTS:
        name = t["name"]
        raw = t["input"]
        expect_error = t["expect_error"]
        expected_output = t["expected_output"]

        try:
            output = run_janet(raw)
            if expect_error:
                print(f"[FAIL] {name}: expected AmbiguousTaskError, got output={output}")
                failed += 1
            else:
                if output == expected_output:
                    print(f"[PASS] {name}")
                    passed += 1
                else:
                    print(f"[FAIL] {name}: expected {expected_output}, got {output}")
                    failed += 1
        except AmbiguousTaskError as e:
            if expect_error:
                print(f"[PASS] {name} (AmbiguousTaskError: {e})")
                passed += 1
            else:
                print(f"[FAIL] {name}: unexpected AmbiguousTaskError: {e}")
                failed += 1
        except Exception as e:
            print(f"[FAIL] {name}: unexpected error type: {e}")
            failed += 1

    print()
    print(f"Summary: {passed} passed, {failed} failed, total {passed+failed}.")


if __name__ == "__main__":
    run_all_tests()
