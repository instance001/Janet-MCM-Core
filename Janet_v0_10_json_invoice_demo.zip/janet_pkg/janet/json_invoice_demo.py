"""JSON-based invoice verification demo for Janet.

This bypasses the phrase normalizer and shows how to use Janet's
existing invoice skill with structured JSON input.

Usage:

    python -m janet.json_invoice_demo path/to/invoice.json

Where `invoice.json` looks like:

    {
        "total": 120,
        "items": [50, 70]
    }

Janet will compute the sum of `items` and compare it to `total`.
"""

import sys
import json
from selectors.mode_selector import select_mode
from selectors.skill_selector import select_skill
from janet_errors import AmbiguousTaskError
from importlib import import_module
from janet import log_event  # reuse logging helper from core


def build_task_from_json(payload: dict) -> dict:
    """Turn a simple JSON payload into a Janet task dict.

    Expected keys:
        - total: int
        - items: list of ints
    """
    if not isinstance(payload, dict):
        raise AmbiguousTaskError("Invoice JSON must be an object.")
    if "total" not in payload or "items" not in payload:
        raise AmbiguousTaskError("Invoice JSON must contain 'total' and 'items'.")
    total = payload["total"]
    items = payload["items"]
    try:
        total_int = int(total)
        items_int = [int(x) for x in items]
    except Exception as e:
        raise AmbiguousTaskError("Invoice JSON contains non-numeric values.") from e

    return {
        "task_type": "invoice_verify_total",
        "total": total_int,
        "items": items_int,
    }


def run_json_invoice(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        payload = json.load(f)

    task = build_task_from_json(payload)
    mode = select_mode(task)
    skill_name = select_skill(mode, task)
    module = import_module(f"skills.{skill_name}")
    output = module.execute(**{k: v for k, v in task.items() if k in module.execute.__code__.co_varnames})
    # Reuse core logging
    log_event(raw_input=f"JSON_FILE:{path}", task=task, mode=mode, skill_name=skill_name, output=output, error=None)
    return output


def main():
    if len(sys.argv) != 2:
        print("Usage: python -m janet.json_invoice_demo path/to/invoice.json")
        raise SystemExit(1)

    path = sys.argv[1]
    try:
        result = run_json_invoice(path)
        print(result)
    except AmbiguousTaskError as e:
        print(f"AmbiguousTaskError: {e}")
        raise SystemExit(2)
    except Exception as e:
        print(f"Error: {e}")
        raise SystemExit(1)


if __name__ == "__main__":
    main()
