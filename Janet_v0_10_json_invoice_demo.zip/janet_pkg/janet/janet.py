import sys
import yaml
from importlib import import_module
from selectors.mode_selector import select_mode
from selectors.skill_selector import select_skill
from skills import input_normalizer
import os
from datetime import datetime
from janet_errors import AmbiguousTaskError

with open("config.yaml") as f:
    CONFIG = yaml.safe_load(f)

LOG_PATH = os.path.join("janet_memory", "candidate", "run_log.txt")

def log_event(raw_input: str, task: dict | None, mode: str | None, skill_name: str | None, output: dict | None, error: str | None = None):
    os.makedirs(os.path.dirname(LOG_PATH), exist_ok=True)
    with open(LOG_PATH, "a") as log_file:
        log_file.write(
            f"[{datetime.utcnow().isoformat()}] input={raw_input!r} "
            f"task={task} mode={mode} skill={skill_name} output={output} error={error}\n"
        )

def run_janet(raw_input: str):
    """Janet v0.2b kernel: normalize → select mode → select skill → execute → log."""
    task = None
    mode = None
    skill_name = None
    output = None
    try:
        task = input_normalizer.normalize(raw_input)
        mode = select_mode(task)
        skill_name = select_skill(mode, task)
        module = import_module(f"skills.{skill_name}")
        output = module.execute(**{k: v for k, v in task.items() if k in module.execute.__code__.co_varnames})
        log_event(raw_input, task, mode, skill_name, output, error=None)
        return output
    except AmbiguousTaskError as e:
        log_event(raw_input, task, mode, skill_name, output, error=str(e))
        raise
    except Exception as e:
        log_event(raw_input, task, mode, skill_name, output, error=f"Unhandled: {e}")
        raise

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print('Usage: python janet.py "add 5 and 7"')
        sys.exit(1)

    raw = sys.argv[1]
    try:
        result = run_janet(raw)
        print(result)
    except AmbiguousTaskError as e:
        print(f"AmbiguousTaskError: {e}")
        sys.exit(2)
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)
