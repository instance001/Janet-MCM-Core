import sys
from datetime import UTC, datetime
from importlib import import_module

import yaml

from . import app_paths
from .janet_errors import AmbiguousTaskError
from .selectors.mode_selector import select_mode
from .selectors.skill_selector import select_skill
from .skills import input_normalizer

with app_paths.config_path().open("r", encoding="utf-8") as f:
    CONFIG = yaml.safe_load(f)

def log_event(raw_input: str, task: dict | None, mode: str | None, skill_name: str | None, output: dict | None, error: str | None = None):
    with app_paths.run_log_path().open("a", encoding="utf-8") as log_file:
        log_file.write(
            f"[{datetime.now(UTC).isoformat()}] input={raw_input!r} "
            f"task={task} mode={mode} skill={skill_name} output={output} error={error}\n"
        )

def run_janet(raw_input: str):
    """Janet v0.2b kernel: normalize → select mode → select skill → execute → log."""
    task = None
    mode = None
    skill_name = None
    output = None
    try:
        task = input_normalizer.normalize(raw_input)
        mode = select_mode(task)
        skill_name = select_skill(mode, task)
        module = import_module(f".skills.{skill_name}", package=__package__)
        output = module.execute(**{k: v for k, v in task.items() if k in module.execute.__code__.co_varnames})
        log_event(raw_input, task, mode, skill_name, output, error=None)
        return output
    except AmbiguousTaskError as e:
        log_event(raw_input, task, mode, skill_name, output, error=str(e))
        raise
    except Exception as e:
        log_event(raw_input, task, mode, skill_name, output, error=f"Unhandled: {e}")
        raise

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print('Usage: python janet.py "add 5 and 7"')
        sys.exit(1)

    raw = sys.argv[1]
    try:
        result = run_janet(raw)
        print(result)
    except AmbiguousTaskError as e:
        print(f"AmbiguousTaskError: {e}")
        sys.exit(2)
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)
