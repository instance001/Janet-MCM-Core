"""Janet MCM package."""

__all__ = ["run_janet"]


def __getattr__(name: str):
    if name == "run_janet":
        from .janet import run_janet

        return run_janet
    raise AttributeError(name)
