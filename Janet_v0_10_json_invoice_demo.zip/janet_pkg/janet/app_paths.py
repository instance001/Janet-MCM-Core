"""Portable path helpers for the Janet demo package."""

from __future__ import annotations

import os
from pathlib import Path


PACKAGE_ROOT = Path(__file__).resolve().parent


def data_root() -> Path:
    """Return the writable Janet data root, creating it on first use.

    By default, unzip-and-run releases write beside the extracted package so
    users can inspect and carry their memory files with the demo. Set
    JANET_MCM_DATA_DIR to redirect writes for installed or scripted use.
    """
    override = os.environ.get("JANET_MCM_DATA_DIR")
    root = Path(override).expanduser() if override else PACKAGE_ROOT
    root.mkdir(parents=True, exist_ok=True)
    return root


def config_path() -> Path:
    return PACKAGE_ROOT / "config.yaml"


def memory_root() -> Path:
    root = data_root() / "janet_memory"
    (root / "candidate").mkdir(parents=True, exist_ok=True)
    (root / "stable").mkdir(parents=True, exist_ok=True)
    return root


def run_log_path() -> Path:
    return memory_root() / "candidate" / "run_log.txt"
