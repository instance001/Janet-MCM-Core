"""Simple CLI wrapper for Janet.

Usage:
    python janet_cli.py run "add 5 and 7"
"""
import sys
from janet import run_janet
from janet_errors import AmbiguousTaskError

def main():
    if len(sys.argv) < 3 or sys.argv[1] != "run":
        print('Usage: python janet_cli.py run "add 5 and 7"')
        raise SystemExit(1)

    raw = sys.argv[2]
    try:
        result = run_janet(raw)
        print(result)
    except AmbiguousTaskError as e:
        print(f"AmbiguousTaskError: {e}")
        raise SystemExit(2)
    except Exception as e:
        print(f"Error: {e}")
        raise SystemExit(1)

if __name__ == "__main__":
    main()
