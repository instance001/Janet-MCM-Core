def metadata():
    return {
        "skill_name": "math.add",
        "input_schema": {"a": int, "b": int},
        "output_schema": {"result": int},
        "tags": ["math"],
        "prereqs": []
    }

def execute(a: int, b: int) -> dict:
    return {"result": a + b}
