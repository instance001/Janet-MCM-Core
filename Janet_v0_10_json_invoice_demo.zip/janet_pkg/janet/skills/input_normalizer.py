from janet_errors import AmbiguousTaskError

def normalize(raw: str) -> dict:
    """Normalize a very small subset of natural-ish inputs.

    Supported forms for this demo:
        - "add 5 and 7"
        - "multiply 3 and 4"
        - "verify invoice total 120 equals items 50, 70"
    """
    raw = raw.lower().strip()

    # math: add
    if raw.startswith("add"):
        cleaned = raw.replace("add", "").replace("and", " ")
        parts = cleaned.split()
        if len(parts) != 2:
            raise AmbiguousTaskError("Expected exactly two numbers for add.")
        try:
            a, b = int(parts[0]), int(parts[1])
            return {"operation": "add", "a": a, "b": b}
        except Exception as e:
            raise AmbiguousTaskError("Could not parse numbers for add.") from e

    # math: multiply
    if raw.startswith("multiply"):
        cleaned = raw.replace("multiply", "").replace("and", " ")
        parts = cleaned.split()
        if len(parts) != 2:
            raise AmbiguousTaskError("Expected exactly two numbers for multiply.")
        try:
            a, b = int(parts[0]), int(parts[1])
            return {"operation": "multiply", "a": a, "b": b}
        except Exception as e:
            raise AmbiguousTaskError("Could not parse numbers for multiply.") from e

    # invoice: verify total
    # Example: "verify invoice total 120 equals items 50, 70"
    if raw.startswith("verify invoice total"):
        prefix = "verify invoice total"
        rest = raw[len(prefix):].strip()
        tokens = rest.split()
        if not tokens or not tokens[0].isdigit():
            raise AmbiguousTaskError("Could not parse invoice total.")
        total = int(tokens[0])

        if "items" not in tokens:
            raise AmbiguousTaskError("Expected 'items' keyword for invoice.")
        items_index = tokens.index("items")
        item_tokens = tokens[items_index+1:]
        if not item_tokens:
            raise AmbiguousTaskError("No item values found for invoice.")
        item_str = " ".join(item_tokens)
        item_str = item_str.replace(" ", "")
        parts = [p for p in item_str.split(",") if p]
        try:
            items = [int(p) for p in parts]
        except Exception as e:
            raise AmbiguousTaskError("Could not parse invoice item values.") from e

        return {
            "task_type": "invoice_verify_total",
            "total": total,
            "items": items
        }

    raise AmbiguousTaskError("Cannot normalize input to a known task.")
