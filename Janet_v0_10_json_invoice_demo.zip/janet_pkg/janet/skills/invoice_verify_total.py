def metadata():
    return {
        "skill_name": "invoice.verify_total",
        "input_schema": {"total": int, "items": list},
        "output_schema": {"ok": bool, "sum": int, "total": int},
        "tags": ["invoice", "verification"],
        "prereqs": []
    }

def execute(total: int, items: list) -> dict:
    computed_sum = sum(int(x) for x in items)
    ok = (computed_sum == total)
    return {"ok": ok, "sum": computed_sum, "total": total}
