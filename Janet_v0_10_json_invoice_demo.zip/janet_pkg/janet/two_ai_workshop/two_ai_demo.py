"""Two-AI Workshop demo: LLM (stub) + Janet working together.

This does NOT call any real LLM – it's a structural example only.

Conceptual flow:

    1. LLM receives a natural language user request.
    2. LLM converts it into a strict Janet-friendly string.
    3. Janet executes deterministically.
    4. LLM reads Janet's result and generates a human-facing explanation.

Here we stub the LLM parts and just print what *would* happen.
"""

from janet import run_janet
from janet_errors import AmbiguousTaskError

def llm_stub_turn_user_request_into_janet_string(user_request: str) -> str:
    """Pretend to be an LLM converting natural language into a Janet task string.

    In a real system, the LLM would be prompted to ONLY output a string that
    Janet can deterministically parse, like:

        "verify invoice total 120 equals items 50, 70"
        "add 5 and 7"
        "multiply 3 and 4"

    For this demo, we just hard-map a couple of example inputs.
    """
    req = user_request.lower().strip()
    if "invoice" in req:
        # Hard-coded mapping for the demo
        return "verify invoice total 120 equals items 50, 70"
    if "add" in req:
        return "add 5 and 7"
    if "multiply" in req:
        return "multiply 3 and 4"
    # Anything else we deliberately treat as ambiguous.
    raise AmbiguousTaskError("LLM stub cannot map this request to a Janet task.")


def llm_stub_explain_result_to_user(user_request: str, janet_input: str, janet_output: dict) -> str:
    """Pretend to be an LLM explaining Janet's deterministic result back to a user."""
    if "invoice" in janet_input:
        if janet_output.get("ok"):
            return (
                f"For your request: '{user_request}', I asked Janet to '{janet_input}'.\n"
                f"Janet confirmed the line items sum to {janet_output['sum']}, which matches the total {janet_output['total']}."
            )
        else:
            return (
                f"For your request: '{user_request}', I asked Janet to '{janet_input}'.\n"
                f"Janet reports a mismatch: line items sum to {janet_output['sum']} but total is {janet_output['total']}."
            )

    if "add" in janet_input:
        return (
            f"For your request: '{user_request}', I asked Janet to '{janet_input}'.\n"
            f"Janet computed the result as {janet_output['result']}."
        )

    if "multiply" in janet_input:
        return (
            f"For your request: '{user_request}', I asked Janet to '{janet_input}'.\n"
            f"Janet computed the result as {janet_output['result']}."
        )

    return (
        f"For your request: '{user_request}', I asked Janet to '{janet_input}'.\n"
        f"Janet returned: {janet_output}."
    )


def run_demo():
    print("=== Two-AI Workshop Demo (stub) ===\n")

    user_requests = [
        "Can you check if this invoice adds up correctly?",
        "Hey, what is 5 plus 7?",
        "What do you get if you multiply 3 by 4?",
    ]

    for req in user_requests:
        print(f"User: {req}")
        try:
            janet_input = llm_stub_turn_user_request_into_janet_string(req)
            print(f"  [LLM → Janet] '{janet_input}'")
            janet_output = run_janet(janet_input)
            explanation = llm_stub_explain_result_to_user(req, janet_input, janet_output)
            print("  [Janet output]", janet_output)
            print("  [LLM explanation]", explanation)
        except AmbiguousTaskError as e:
            print(f"  [LLM/Janet ambiguity] {e}")
        except Exception as e:
            print(f"  [Unhandled error] {e}")
        print()

if __name__ == "__main__":
    run_demo()
