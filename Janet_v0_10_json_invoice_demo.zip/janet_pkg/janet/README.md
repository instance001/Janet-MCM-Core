# Janet v0.3 – Minimal Modest Cognition Model Prototype (with invoice demo, errors, and CLI)

This is a tiny working Janet kernel: a deterministic,
non-neural Modest Cognition Model that can:

- Add two numbers
- Multiply two numbers
- Verify an invoice total against line items

Now with:

- Central `AmbiguousTaskError`
- Run logging including error states
- A simple `janet_cli.py` wrapper

## Requirements

- Python 3.10+
- `pyyaml` installed (`pip install pyyaml`)

## How to run (direct kernel)

```bash
cd janet_v0_1
python janet.py "add 5 and 7"
python janet.py "multiply 3 and 4"
python janet.py "verify invoice total 120 equals items 50, 70"
```

## How to run via CLI wrapper

```bash
python janet_cli.py run "add 5 and 7"
python janet_cli.py run "multiply 3 and 4"
python janet_cli.py run "verify invoice total 120 equals items 50, 70"
```

Expected output:

```bash
{'result': 12}
{'result': 12}
{'ok': True, 'sum': 120, 'total': 120}
```

## What this demo shows

- Deterministic input normalization
- Mode selection (`math` vs `invoice`)
- Skill selection within a mode
- Explicit skill execution
- Structured error type `AmbiguousTaskError`
- Run logging to `janet_memory/candidate/run_log.txt`
- No randomness, no weights, no embeddings

This is the first runnable Modest Cognition Model (MCM) prototype with a
"real world" flavored task (invoice total verification), a central ambiguity
error type, and a starter CLI wrapper.


## Test Lab (smoke tests)

A tiny `test_lab` harness is included.

To run the smoke tests:

```bash
cd janet_v0_1
python test_lab/run_smoke_tests.py
```

You should see a series of [PASS]/[FAIL] lines and a summary like:

```bash
[PASS] add basic
[PASS] multiply basic
[PASS] invoice total ok
[PASS] ambiguous add (words instead of numbers)
[PASS] ambiguous invoice (bad total)

Summary: 5 passed, 0 failed, total 5.
```

This is the start of the Janet Test Lab: a deterministic,
text-based verification harness for MCM behavior.


## Two-AI Workshop (LLM + Janet demo)

A small `two_ai_workshop` module is included to illustrate how an LLM and Janet
can work together in a composite cognition loop.

This demo does **not** call any real LLM – it just stubs the behavior.

To run the stub demo:

```bash
cd janet_pkg
python -m janet.two_ai_workshop.two_ai_demo
```

You will see:

- A fake "LLM" turning a natural language request into a strict Janet string
- Janet executing deterministically
- A fake "LLM" turning Janet's output into a user-facing explanation

This is the structural pattern for the Two-AI Workshop:
LLM for flexible language and ambiguity handling,
Janet for deterministic, inspectable reasoning.

## Install from source (developer mode)

This package is structured with a `pyproject.toml` for future distribution.

To install in editable/developer mode (once copied to your machine):

```bash
cd janet_pkg
pip install -e .
```

Then you can import Janet in Python code as:

```python
from janet import run_janet
```


## Package name

When built as a Python package, this project uses the name:

    janet-mcm-core

to emphasize that this repository provides the **core** deterministic
Modest Cognition Model engine, rather than a full application stack.


## JSON-based invoice verification demo

You can also exercise Janet's invoice verification skill with a simple JSON file,
bypassing the phrase normalizer.

Example invoice JSON (see `janet/examples/invoice_example.json`):

```json
{
  "total": 120,
  "items": [50, 70]
}
```

Run the demo with:

```bash
cd janet_pkg
python -m janet.json_invoice_demo janet/examples/invoice_example.json
```

Expected output:

```bash
{'ok': True, 'sum': 120, 'total': 120}
```

This shows how to feed Janet **structured data** directly, while still
using the existing mode/skill selection and logging pipeline.
