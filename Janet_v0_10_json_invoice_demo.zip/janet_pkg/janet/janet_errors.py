class AmbiguousTaskError(Exception):
    """Raised when Janet cannot deterministically interpret an input."""
    pass


class DeterminismError(Exception):
    """Raised when something violates a determinism invariant."""
    pass
