from janet_errors import AmbiguousTaskError

def select_mode(task: dict) -> str:
    """Return mode based on task shape."""
    if task.get("task_type") == "invoice_verify_total":
        return "invoice"
    if "operation" in task and "a" in task and "b" in task:
        return "math"
    raise AmbiguousTaskError("Input does not match any known mode.")
