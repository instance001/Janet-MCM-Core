from janet_errors import AmbiguousTaskError

def select_skill(mode: str, task: dict) -> str:
    if mode == "math":
        op = task.get("operation")
        if op == "add":
            return "math_add"
        if op == "multiply":
            return "math_multiply"
    if mode == "invoice":
        if task.get("task_type") == "invoice_verify_total":
            return "invoice_verify_total"
    raise AmbiguousTaskError("No matching skill for given task.")
